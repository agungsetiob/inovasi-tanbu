<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=yes" />
    <meta name="description" content="SERASI Tanah Bumbu" />
    <meta name="author" content="Tanah Bumbu" />
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>Sistem Informasi Riset dan Inovasi</title>
    <link rel="icon" type="image/x-icon" href="{{asset('assets/img/logo.png')}}" />
    <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
    <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet"
        type="text/css" />
    <link href="{{asset('css/styles.css')}}" rel="stylesheet" />
    <link rel="stylesheet" href="{{asset('css/owl.carousel.min.css')}}">
    <link rel="stylesheet" href="{{asset('css/owl.theme.default.min.css')}}">
    <link href="https://cdn.datatables.net/2.0.7/css/dataTables.bootstrap5.css" rel="stylesheet">
    <script src="{{asset('vendor/jquery/jquery.min.js')}}"></script>
    <script src="js/js/bootstrap.bundle.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="https://cdn.datatables.net/2.0.7/js/dataTables.js"></script>
    <script src="https://cdn.datatables.net/2.0.7/js/dataTables.bootstrap5.js"></script>
    <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous" defer></script>
    <script src="js/js/scripts.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/use-bootstrap-select@2.1.1/dist/use-bootstrap-select.min.css">
    <script src="https://cdn.jsdelivr.net/npm/use-bootstrap-select@2.1.1/dist/use-bootstrap-select.min.js"></script>
    <script type="text/javascript" src="{{asset('vendor/tanbu/tanbu.min.js')}}"></script>
    <script type="text/javascript" src="{{asset('vendor/tanbu/loading-states.js')}}"></script>
</head>
<body id="page-top" class="rotate-and-zoom-out" style="background-image: url('../img/background.svg');" hx-ext="loading-states">
    <noscript>
        @include('errors.noscript')
    </noscript>
    <div class="container">
        <div class="row justify-content-between pt-4">
            <img style="width:93px" class="img-fluid" src="assets/img/logo.png" title="garuda" alt="garuda" />
            <img style="width:175px" class="img-fluid" src="assets/img/akhlak.png" title="tanbu" alt="tanbu" />
        </div>
    </div>
    <!-- Masthead-->
    <header id="wrapper" class="masthead text-white text-center"
        style="margin-top: 0px; padding-top: 0px; padding-bottom: 0.1rem; margin-bottom: 0px;" hx-history="false">
        @foreach ($settings as $s)
        <div class="container d-flex align-items-center justify-content-center">
            <img style="height:193px" class="img-fluid mb-2" src="{{url('storage/system/' . $s->logo_cover)}}"
                title="logo" alt="logo" />
        </div>
        @endforeach
        <div class="container d-flex align-items-center flex-column">
            <h3 class="text-uppercase text-dark">Kabupaten Tanah Bumbu</h3>
            <!-- Icon Divider-->
        </div>

        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-6 col-lg-3 mb-5 mb-lg-0">
                    <div class="portfolio-item mx-auto text-center">
                        <img class="img-fluid menu-logo fa-bounce bounce-no-animation" src="assets/img/rocket.png"
                            alt="..." />
                        <a hx-get="{{url('inovasi')}}" hx-trigger="click" hx-target="#page-top"
                            hx-swap="outerHTML transition:true" hx-push-url="true" hx-indicator="#loadingIndicator"
                            class="btn btn-lg btn-outline-secondary btn-block masthead-subheading fw-semibold mb-0"
                            style="display: flex; justify-content: center; align-items: center;">INOVASI</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3 mb-5 mb-lg-0">
                    <div class="portfolio-item mx-auto">
                        <img class="img-fluid menu-logo-atom fa-spin-pulse" src="assets/img/atom.png" alt="..." />
                        <a
                        hx-get="{{url('risets')}}" 
                        hx-trigger="click" 
                        hx-target="#page-top" 
                        hx-swap="outerHTML transition:true"
                        hx-push-url="true"
                        hx-indicator="#loadingIndicator"
                        class="btn btn-lg btn-outline-secondary btn-block masthead-subheading fw-semibold mb-0"
                        style="display: flex; justify-content: center; align-items: center;">RISET</a>
                    </div>
                </div>
                <div class="col-md-6 col-lg-3 mb-5 mb-lg-0">
                    <div class="portfolio-item mx-auto">
                        <img class="img-fluid menu-logo fa-flip" src="assets/img/microscope.png" alt="..." />
                        <a 
                        hx-get="{{ url('evaluasi') }}"
                        hx-trigger="click"
                        hx-target="#page-top"
                        hx-swap="outerHTML transition:true"
                        hx-push-url="true"
                        hx-indicator="#loadingIndicator"
                        class="btn btn-lg btn-outline-secondary btn-block masthead-subheading fw-semibold mb-0" style="display: flex; justify-content: center; align-items: center;">EVALUASI</a>
                    </div>
                </div>
            </div>
        </div>
    </header>
    @include('visitor.partial.htmx-indicator')
    <script>
        $('#slider').owlCarousel({
            items: 1,
            lazyLoad: true,
            nav: false,
            navText: false,
            loop: true,
            autoplay: true,
            responsive: {
                0: {
                    items: 1,
                    stagePadding: 0
                },
                600: {
                    items: 1,
                    stagePadding: 0
                },
                900: {
                    items: 1,
                    stagePadding: 100
                },
                1200: {
                    items: 1,
                    // stagePadding: 250
                    stagePadding: 130
                },
                1400: {
                    items: 1,
                    // stagePadding: 300
                    stagePadding: 130
                },
                1600: {
                    items: 1,
                    stagePadding: 350
                },
                1800: {
                    items: 1,
                    stagePadding: 400
                }
            }
        });
    </script>
</body>

</html>